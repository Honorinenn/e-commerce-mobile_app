// constants/index.js
export const API_BASE = 'http://YOUR_SERVER_IP:3000';