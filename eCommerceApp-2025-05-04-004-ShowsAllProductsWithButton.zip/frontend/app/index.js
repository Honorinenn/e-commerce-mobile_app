import { registerRootComponent } from 'expo';
import App from './(tabs)/App';

registerRootComponent(App);